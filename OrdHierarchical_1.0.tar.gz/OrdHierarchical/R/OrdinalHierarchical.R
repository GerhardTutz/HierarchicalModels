OrdinalHierarchical <-
function(dat,k,nameresp,pred,preda,preddis,tests,preddisp,predequal){

  if (is.null(predequal)){
    d <- MakeDesign(dat,k,nameresp,pred,preda,preddis)
  } else{
    d <- MakeDesignEqual(dat,k,nameresp,pred,preda,preddis,predequal)
  }

  ###################################
  ###fits global/grouped

  incr<-.2
  knew<-dim(as.matrix(d$respmgr))[2]
  thr<- seq(1,knew-1,1)*incr
  beta<-c(thr,rep(.0,length(pred)))
  d$Xgr<-as.matrix(d$Xgr)


  fitsgr <- suppressWarnings(optim(beta, Loglikcum, gr = scorecum,d$respmgr,d$ngrgr,d$Xgr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))

  errgr<- solve(fitsgr$hessian)
  stdgr<- sqrt(diag(errgr))
  probgr<-LoglikcumFit(fitsgr$par,d$respmgr,d$ngrgr,d$Xgr)


  ##output generation

  z<-fitsgr$par/stdgr
  pvalgr <-(1-pnorm(abs(z), mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE))*2

  parmgr<- cbind(fitsgr$par,stdgr,z,pvalgr)
  parmgr<-as.data.frame(parmgr)

  names(parmgr)[1] <- "Estimates"
  names(parmgr)[2] <- "std err"
  names(parmgr)[3] <- "z-values"
  names(parmgr)[4] <- "p-values"
  if(length(pred)>0)row.names(parmgr)<-c(seq(1,(knew-1),1),paste(pred))


  ###################### end global
  knew<-dim(as.matrix(d$respm))[2]

  if(is.null(preddisp)){
  #fits disagree,agree and tests if predisp not NULL

    incr<-.1
    thr<- seq(1,knew-1,1)*incr
    beta<-c(thr,thr,rep(.0,length(preddis)),rep(.0,length(preda)))
    beta<-c(thr,thr,rep(.0,dim(d$X)[2]))
    #LoglikInt(beta,d$respm,d$ngr,d$X,d$indagr)
    #Loglikcum(beta,d$respm,d$ngr,d$X)

    fits <- suppressWarnings(optim(beta, LoglikInt, gr = scoreInt,d$respm,d$ngr,d$X,d$indagr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))
    fits
    err<- solve(fits$hessian)
    std<- sqrt(diag(err))

    ##output generation

    z<-fits$par/std
    pval <-(1-pnorm(abs(z), mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE))*2

    parm<- cbind(fits$par,std,z,pval)
    parm<-as.data.frame(parm)

    names(parm)[1] <- "Estimates"
    names(parm)[2] <- "std err"
    names(parm)[3] <- "z-values"
    names(parm)[4] <- "p-values"


    if(is.null(predequal)){
      if(length(preddis)*length(preda)>0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("disagree",preddis),paste("agree",preda))
      if(length(preddis)==0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("agree",preda))
      if(length(preda)==0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("disagree",preddis))
    }

    if(!is.null(predequal)){predwithout<-setdiff(pred, predequal)
    predawithout<-setdiff(preda, predequal)
    preddiswithout<-setdiff(preddis, predequal)
    if(length(predawithout)*length(preddiswithout)>0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("equal",predequal),paste("disagree",preddiswithout),paste("agree",predawithout))
    if(length(predawithout)==0 & length(preddiswithout)>0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("equal",predequal),paste("disagree",preddiswithout))
    if(length(preddiswithout)==0 & length(predawithout)>0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("equal",predequal),paste("agree",predawithout))
    if(length(preddiswithout)==0 & length(predawithout)==0)row.names(parm)<-c(seq(1,2*(knew-1),1),paste("equal",predequal))
    }
    ### log-likelihood

    probnonneutr<-LoglikIntFit(fits$par,d$respm,d$ngr,d$X,d$indagr)
    sum <-0

    dat0<-d$datmod  ### extended data


    ### k odd
    if(k/2 !=floor(k/2)){
      for (i in 1:dim(dat0)[1]) {respn<-dat0$resp0[i]
      obs<-dat0$obs[i]

      if(respn==(k+1)/2)prob<-probgr[i]
      probnow<-0
      if(respn!=(k+1)/2){
        for (s in 1:dim(d$X)[1]){  if(d$obsind[s]==obs) probnow<-probnonneutr[s] }
        prob<-probgr[i]*probnow
      }

      #print (i)
      #print(probnow)
      sum<-sum+log(prob)

      }
      loglik<-sum
      dim(d$X)[2]
      #numpar<-length(pred)+length(preda)+length(preddis)+2+2*(k-3)/2
      numpar<-length(pred)+2+ dim(d$X)[2]+(k-3)
      AIC<--2*(loglik-numpar)
    } ### k odd


    ### k even
    if(k/2 ==floor(k/2)){
      for (i in 1:dim(dat0)[1]) {respn<-dat0$resp0[i]
      obs<-dat0$obs[i]

      #if(respn==(k+1)/2)prob<-probgr[i]
      probnow<-0
      #if(respn!=(k+1)/2){
      for (s in 1:dim(d$X)[1]){  if(d$obsind[s]==obs) probnow<-probnonneutr[s] }
      prob<-probgr[i]*probnow
      #}

      #print (i)
      #print(probnow)
      sum<-sum+log(prob)

      }
      loglik<-sum
      #numpar<-length(pred)+length(preda)+length(preddis)+1+2*(k/2-1)
      numpar<-length(pred)+1+ dim(d$X)[2]+2*(k/2-1)
      AIC<--2*(loglik-numpar)
    } ### k even




    #### Tests
    if(!is.null(predequal) | !is.null(preddisp)) tests<-"no"

    matrixtests<-0
    matrixdisp<-0

    if(tests=="Wald") {
      dbet<-length(beta)
      varnum<-length(pred)

      ### equality
      matrixtests<-matrix (0, varnum,2)
      for(v in 1:varnum){
        C<-matrix(0,1,dbet)
        var<-v
        C[1,2*(knew-1)+var]<-1
        C[1,2*(knew-1)+length(pred)+var]<--1
        #w<- C%*%fits$par*(C%*%err%*%t(C))^(-1)*C%*%fits$par
        w <- t(C %*% fits$par) %*% solve(C %*% err %*% t(C)) %*% (C %*% fits$par)
        pvalt<-1-pchisq(w, df=1)
        matrixtests[v,1]<-w
        matrixtests[v,2]<-pvalt
      }
      matrixtests
      round(matrixtests, digits = 3)
      colnames(matrixtests)  <- c("z-values","p-values")
      row.names(matrixtests)<-c(paste(pred))

      ### dispersiontests
      matrixdisp<-matrix (0, varnum,2)
      for(v in 1:varnum){
        C<-matrix(0,1,dbet)
        var<-v
        C[1,2*(knew-1)+var]<-1
        C[1,2*(knew-1)+length(pred)+var]<-1
        w<- C%*%fits$par*(C%*%err%*%t(C))^(-1)*C%*%fits$par
        pvalt<-1-pchisq(w, df=1)
        matrixdisp[v,1]<-w
        matrixdisp[v,2]<-pvalt
      }
      matrixdisp
      round(matrixdisp, digits = 3)
      colnames(matrixdisp)  <- c("z-values","p-values")
      if(length(preddis)*length(preda)>0)row.names(matrixdisp)<-c(paste(pred))
      if(length(preddis)==0)row.names(matrixdisp)<-c(seq(1,2*(knew-1),1),paste("agree",preda))
      if(length(preda)==0)row.names(matrixdisp)<-c(seq(1,2*(knew-1),1),paste("disagree",preddis))
    }   ### end Wald

    if(tests=="LR") {
      dbet<-length(beta)
      varnum<-length(pred)
      matrixtests<-matrix (0, varnum,2)
      ### equality

      for(v in 1:varnum){
        #C<-matrix(0,1,dbet)
        equal<-pred[v]
        d<-MakeDesignEqual(dat,k,nameresp,pred,preda,preddis,equal)

        incr<-.1
        thr<- seq(1,knew-1,1)*incr
        numpar<-2*length(thr)+dim(d$X)[2]
        beta<-c(thr,thr,rep(.0,dim(d$X)[2]))
        fitst <- suppressWarnings(optim(beta, LoglikInt, gr = scoreInt,d$respm,d$ngr,d$X,d$indagr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = FALSE))

        lr<- -2*(-fitst$value+ fits$value)
        pvalt<-1-pchisq(lr, df=1)
        matrixtests[v,1]<-lr
        matrixtests[v,2]<-pvalt
      }  ### v
      matrixtests
      round(matrixtests, digits = 3)
      colnames(matrixtests)  <- c("z-values","p-values")
      row.names(matrixtests)<-c(paste(pred))

      ### dispersiontests

      matrixdisp<-matrix (0, varnum,2)
      for(v in 1:varnum){
        #C<-matrix(0,1,dbet)
        disp<-pred[v]
        d<-MakeDesignDisp(dat,k,nameresp,pred,preda,preddis,disp)
        incr<-.1
        thr<- seq(1,knew-1,1)*incr
        numpar<-2*length(thr)+dim(d$X)[2]
        beta<-c(thr,thr,rep(.0,dim(d$X)[2]))
        fitst <- suppressWarnings(optim(beta, LoglikInt, gr = scoreInt,d$respm,d$ngr,d$X,d$indagr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = FALSE))

        lr<- -2*(-fitst$value+ fits$value)
        pvalt<-1-pchisq(lr, df=1)
        matrixdisp[v,1]<-lr
        matrixdisp[v,2]<-pvalt
      }  ### v
      matrixdisp
      round(matrixdisp, digits = 3)
      colnames(matrixdisp)  <- c("z-values","p-values")
      if(length(preddis)*length(preda)>0)row.names(matrixdisp)<-c(paste(pred))
      if(length(preddis)==0)row.names(matrixdisp)<-c(seq(1,2*(knew-1),1),paste("agree",preda))
      if(length(preda)==0)row.names(matrixdisp)<-c(seq(1,2*(knew-1),1),paste("disagree",preddis))

    }   ### end LR
  }
  #### model with dispersion


  if(!is.null(preddisp)){
    incr<-.1
    thr<- seq(1,knew-1,1)*incr

    ##new
    d<-MakeDesignDisp(dat,k,nameresp,pred,preda,preddis,preddisp)
    d$X
    numpar<-2*length(thr)+dim(d$X)[2]
    beta<-c(thr,thr,rep(.0,dim(d$X)[2]))
    length(beta)
    #LoglikInt(beta,d$respm,d$ngr,d$X,d$indagr)
    fitsp <- suppressWarnings(optim(beta, LoglikInt, gr = scoreInt,d$respm,d$ngr,d$X,d$indagr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))
    fitsp

    err<- solve(fitsp$hessian)
    std<- sqrt(diag(err))

    z<-fitsp$par/std
    pval <-(1-pnorm(abs(z), mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE))*2

    ##output generation



    parmdisp<- cbind(fitsp$par,std,z,pval)
    parmdisp<-as.data.frame(parmdisp)


    predwithout<-setdiff(pred, preddisp)
    predawithout<-setdiff(preda, preddisp)
    preddiswithout<-setdiff(preddis, preddisp)
    if(length(predawithout)*length(preddiswithout)>0)row.names(parmdisp)<-c(seq(1,2*(knew-1),1),paste("dispersion",preddisp),paste("disagree",preddiswithout),paste("agree",predawithout))
    if(length(predawithout)==0 & length(preddiswithout)>0)row.names(parmdisp)<-c(seq(1,2*(knew-1),1),paste("dispersion",preddisp),paste("disagree",preddiswithout))
    if(length(preddiswithout)==0 & length(predawithout)>0)row.names(parmdisp)<-c(seq(1,2*(knew-1),1),paste("dispersion",preddisp),paste("agree",predawithout))
    if(length(preddiswithout)==0 & length(predawithout)==0)row.names(parmdisp)<-c(seq(1,2*(knew-1),1),paste("dispersion",preddisp))

    parmdisp
    parmdisp<-as.data.frame(parmdisp)

    names(parmdisp)[1] <- "Estimates"
    names(parmdisp)[2] <- "std err"
    names(parmdisp)[3] <- "z-values"
    names(parmdisp)[4] <- "p-values"



    ### log-likelihood

    probnonneutr<-LoglikIntFit(fitsp$par,d$respm,d$ngr,d$X,d$indagr)
    sum <-0

    dat0<-d$datmod  ### extended data

    ### k odd
    if(k/2 !=floor(k/2)){
      for (i in 1:dim(dat0)[1]) {respn<-dat0$resp0[i]
      obs<-dat0$obs[i]

      if(respn==(k+1)/2)prob<-probgr[i]
      probnow<-0
      if(respn!=(k+1)/2){
        for (s in 1:dim(d$X)[1]){  if(d$obsind[s]==obs) probnow<-probnonneutr[s] }
        prob<-probgr[i]*probnow
      }

      #print (i)
      #print(probnow)
      sum<-sum+log(prob)

      }  ### i

      loglikdisp<-sum
      #numpar<-length(pred)+length(preda)+length(preddis)+2+2*(k-3)/2
      #AICdisp<--2*(loglikdisp-(numpar-length(preddisp)))
      numpar<-length(pred)+2+ dim(d$X)[2]+(k-3)
      AICdisp<--2*(loglikdisp-numpar)
    }  ### k odd

    ### k even
    if(k/2 ==floor(k/2)){
      for (i in 1:dim(dat0)[1]) {respn<-dat0$resp0[i]
      obs<-dat0$obs[i]

      #if(respn==(k+1)/2)prob<-probgr[i]
      probnow<-0
      #if(respn!=(k+1)/2){
      for (s in 1:dim(d$X)[1]){  if(d$obsind[s]==obs) probnow<-probnonneutr[s] }
      prob<-probgr[i]*probnow
      #}

      #print (i)
      #print(probnow)
      sum<-sum+log(prob)

      }
      loglikdisp<-sum
      #numpar<-length(pred)+length(preda)+length(preddis)+1+2*(k/2-1)
      #AICdisp<--2*(loglikdisp-(numpar-length(preddisp)))
      numpar<-length(pred)+1+ dim(d$X)[2]+2*(k/2-1)
      AICdisp<--2*(loglikdisp-numpar)
    }   ### k even

  } ## disp
  ############################


  if(is.null(preddisp) & is.null(predequal)) newList <- list("loglik"=loglik,"AIC"=AIC,"pargroupedresponse"=parmgr,"loglikgroupedmodel"=-fitsgr$value,"parnonneutral"=parm,"logliknonneutral"=-fits$value,
                                                             "testsequality"=matrixtests, "testsdispersion"=matrixdisp)

  if(!is.null(predequal)) newList <- list("loglik"=loglik,"AIC"=AIC,"pargroupedresponse"=parmgr,"loglikgroupedmodel"=-fitsgr$value,"parnonneutral"=parm,"logliknonneutral"=-fits$value,
                                        "testsequality"=NA, "testsdispersion"=NA)

  if(!is.null(preddisp)) newList <- list("loglik"=loglikdisp,"AIC"=AICdisp, "pargroupedresponse"=parmgr,"loglikgroupedmodel"=-fitsgr$value,"parnonneutral"=parmdisp,"logliknonneutral"=-fitsp$value,
                                       "testsequality"=NA, "testsdispersion"=NA)


  return(newList)


  }
