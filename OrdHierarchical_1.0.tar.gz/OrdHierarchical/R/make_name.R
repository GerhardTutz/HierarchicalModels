make_name <-
function(sub) {
  if (!is.list(sub)) sub <- as.list(sub)
  parts <- vapply(sub, function(x) paste0(x, collapse = ""), character(1))
  paste(parts, collapse = "/")
}
