OrdinalHierarchicalTreesNeutral <-
function(dat,k,nameresp,pred,predn,fittype,cum,fam){

  fit<-0

  if(cum){
    listcat<-list(list(c(seq(1,(k-1)/2,1),seq((k+1)/2+1,k,1)), (k+1)/2 ), as.list(c(seq(1,(k-1)/2,1),seq((k+1)/2+1,k,1))) )
    listpred<-list(predn,pred)
  }

  if(!cum){
    listcat<-list(list(c(seq(1,(k-1)/2,1),seq((k+1)/2+1,k,1)), (k+1)/2 ), list(seq(1,(k-1)/2,1),seq((k+1)/2+1,k,1))  ,as.list(seq(1,(k-1)/2,1)),as.list(seq((k+1)/2+1,k,1)))
    listpred<-list(predn,pred,pred,pred)
  }

  fit<-PolyTreesGen(dat,k,nameresp,listcat,listpred,fittype,fam)

  newList <- fit
  return(newList)

}
