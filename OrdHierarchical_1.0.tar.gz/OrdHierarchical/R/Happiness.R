#'@name Happiness
#'
#'@title Relational goods and Leisure time dataset
#'
#'@description
#'Dataset consists of the results of a survey aimed at measuring the evaluation of people living in the
#'metropolitan area of Naples, Italy, with respect to of relational goods and leisure time collected in
#'December 2014. Every participant was asked to assess on a 10 point ordinal scale his/her personal
#'score for several relational goods (for instance, time dedicated to friends and family) and to leisure
#'time. In addition, the survey asked respondents to self-evaluate their level of happiness by marking
#'a sign along a horizontal line of 110 millimeters according to their feeling, with the left-most extremity standing for "extremely unhappy", and the right-most extremity corresponding to the status
#'"extremely happy". It's a modified version of the dataset \code{\link[CUB]{relgoods}} contained in the R package \code{CUB}.
#'
#'@docType data
#'@usage data(Happiness)
#'
#'@format A data frame containing the following covariates
#'
#'\code{Gender } 0: male, 1: female
#'
#'\code{Safety }  Level of safety in the streets,  ranging from 1 = "never, at all" to 10 = "always"
#'
#'\code{Birthyear } A variable indicating the year of birth of the respondent
#'
#'\code{Education } 1 = compulsory school, 2 = high school diploma, 3 = Graduated-Bachelor degree, 4 = Graduated-Master degree, 5 = Post graduated
#'
#'\code{Walk  } 1 = usually walking alone, 0 = usually walking in company
#'
#'\code{Neighbours } Quality of the relationships with neighbors,  ranging from 1 = "never, at all" to 10 = "always"
#'
#'\code{Environment } Level of comfort with the surrounding environment,  ranging from 1 = "never, at all" to 10 = "always"
#'
#'\code{Happiness } Each respondent was asked to mark a sign on a 110mm horizontal line according to his/her feeling of happiness
#'(left endpoint corresponding to completely unhappy, rightmost endpoint corresponding to extremely happy)
#'
#'\code{happicat } Happiness in discrete categories,  ranging from 1 = "never, at all" to 10 = "always"
#'
#'\code{Age } Age in years
#'
#'
#'@references
#'Iannario M, Piccolo D, Simone R (2024). _CUB: A Class of Mixture Models for Ordinal Data_. R package version 1.1.5,
#'<https://CRAN.R-project.org/package=CUB>.
#'
#'@examples
#'data(Happiness)
#'table(Happiness$happicat)
#'
#'
NULL



