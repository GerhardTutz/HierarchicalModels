#' Plots for Structured Hierarchical Regression
#'
#' @description
#' Function to build and to plot the structure of the hierarchical model represented as a tree.
#'
#'@param x Object of class \code{OrdHierarchical}.
#'@param ... Further arguments passed to or from other methods.
#'
#'@return
#'The function returns a object of class \code{\link[data.tree]{Node}}, for which the methods
#'\code{print} and \code{plot} are available.
#'
#'@examples
#'data(GLES)
#'
#'hier2 <- OrdHierarchical(dat=GLES, k=7, nameresp="Terrorism",
#'fittype="clm", pred=c("Age","Gender","Abitur"))
#'
#'structure_hier2 <- buildTree(hier2)
#'print(structure_hier2, "level")
#'plot(structure_hier2)
#'
#'@importFrom data.tree Node
#'@export
#'


buildTree <-
function(x,
         ...) {

  if(as.list(attributes(x)$call)[-1]$fittype=="disp"){
    stop("Function buildTree is only applicable for fittype 'clm' or 'vglm'")
  }

  nodes <- attributes(x)$structure
  for(n in 1:length(nodes)){
    nodesn <- nodes[[n]]
    nodes[[n]] <- vector("list", length(nodes)+1)
    nodes[[n]][[1]] <- unlist(nodesn)
    nodes[[n]][-1]  <- nodesn
  }

  resulting_tree <- build_tree(nodes[[1]][[1]], nodes)

  return(resulting_tree)
}
