#'@name GLES
#'
#'@title German Longitudinal Election Study 2017 (GLES17)
#'
#'@description
#'Data from the German Longitudinal Election Study (GLES) from 2017 (Rossteutscher et al., 2017, https://doi.org/10.4232/1.12927).
#'The GLES is a long-term study of the German electoral process. It collects pre- and post-election data for several federal elections,
#'the data used here originate from the pre-election study for 2017.
#'
#'@docType data
#'@usage data(GLES)
#'
#'@format A data frame containing data from the German Longitudinal Election Study with 2036 observations.
#'The data contain socio-demographic information about the participants as well as their responses to items about specific political fears.
#'
#'\code{RefugeeCrisis } How afraid are you due to the refugee crisis? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{ClimateChange } How afraid are you due to the global climate change? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{Terrorism } How afraid are you due to the international terrorism? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{Globalization } How afraid are you due to the globalization? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{Turkey } How afraid are you due to the political developments in Turkey? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{NuclearEnergy } How afraid are you due to the use of nuclear energy? (Likert scale from 1 (not afraid at all) to 7 (very afraid))
#'
#'\code{Age } Age in years
#'
#'\code{Gender } 0: male, 1: female
#'
#'\code{EastWest } 0: West Germany, 1: East Germany
#'
#'\code{Abitur  } High School Diploma, 1: Abitur/A levels, 0: else
#'
#'\code{Unemployment } 1: currently unemployed, 0: else
#'
#'@source
#'https://gles-en.eu/ and doi:10.4232/1.12927
#'
#'@references
#'Rossteutscher, S., Schmitt-Beck, R., Schoen, H., Wessels, B., Wolf, C., Bieber, I., Stovsand, L.-C., Dietz, M., and Scherer, P. (2017). Pre-election cross section (GLES 2017).
#'GESIS Data Archive, Cologne, ZA6800 Data file Version 2.0.0., doi:10.4232/1.12927.
#'
#'@examples
#'data(GLES)
#'table(GLES$Terrorism)
#'
#'
NULL



