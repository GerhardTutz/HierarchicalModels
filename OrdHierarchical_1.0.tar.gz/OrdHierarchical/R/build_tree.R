build_tree <- function(parent_set, nodes) {
  parent_label <- format_label(parent_set)
  node_obj <- Node$new(parent_label)

  # find corresponding split definition
  idx <- which(sapply(nodes, function(x) identical(sort(x[[1]]), sort(parent_set))))
  if(length(idx) == 0) return(node_obj)

  children <- nodes[[idx]][-1]  # remove parent itself
  for(child in children) {
    node_obj$AddChildNode(build_tree(child, nodes))
  }
  return(node_obj)
}
