OrdinalHierarchicalTrees <-
function(dat,k,nameresp,pred,preda,preddis,fittype,fam){

  listpred<-list(pred,preda,preddis)

  ### k odd
  if(k/2 !=floor(k/2)){
    listcat<-list(list(seq(1,(k-1)/2,1),(k+1)/2,seq((k+1)/2+1,k,1)),as.list(seq(1,(k-1)/2,1)),as.list(seq((k+1)/2+1,k,1)))
  }
  if(k/2 ==floor(k/2)){
    listcat<-list(list(seq(1,k/2,1),seq(k/2+1,k,1)),as.list(seq(1,k/2,1)),as.list(seq(k/2+1,k,1)))
  }

  fit<-PolyTreesGen(dat,k,nameresp,listcat,listpred,fittype,fam)

  newList <- fit
  return(newList)


}
