PolyTreesGen <-
function(dat,k,nameresp,listcat,listpred,fittype, fam){

  ### list names
  name_elems <- lapply(listcat, make_name)
  newlist <- as.list(name_elems)
  #####################

  dat$resp<-dat[,nameresp]
  dat$resp<-as.numeric(dat$resp)

  ### grouped responses

  ## loop comp ### list component
  logliktotal<-0
  AICtotal<-0
  for (comp in 1:length(listcat)){
  dat$respgr<-dat$resp  ## grouped response

    lim<-dim(dat)[1]
    length(listcat[[1]])
    for (i in 1:lim) {
      for (ic in 1:length(listcat[[comp]])){
      if (dat$resp[i]%in%unlist(listcat[[comp]][[ic]]))dat$respgr[i]<-ic
    }}

    datred<-dat[dat$resp%in%unlist(listcat[[comp]]),]

      formula <- as.formula(paste("respgr", "~", paste(unlist(listpred[[comp]]), collapse = " + ")))
      formula

    if(fittype!="clm"){
      datred$respgr<-as.ordered(datred$respgr)
      if(fam=="cum")fitgr <- vglm(formula,family=cumulative(parallel=TRUE,reverse=TRUE),data=datred)
      if(fam=="acat")fitgr <- vglm(formula,family=acat(parallel=TRUE,reverse=TRUE),data=datred)
      #fitgra <- vgam(formula,family=cumulative(parallel=TRUE,reverse=TRUE),data=datred)  ### with vgam
      #summary(fitgr)
      #summary(fitgra)
            #res<-list(listcat[[comp]],summary(fitgr))
            res<-list(fitgr)
            logliktotal<-logliktotal+logLik(fitgr)
            AICtotal<-AICtotal+AIC(fitgr)
                                        } #nonclm
    if(fittype=="clm"){
      datred$respgr <- as.factor(datred$respgr)
      if(fam=="cum")fitgr <- clm(formula,  data=datred, link = "logit")
      summary(fitgr)
      #res<-list(listcat[[comp]],summary(fitgr))
      res<-list(fitgr)
      logliktotal<-logliktotal+fitgr$logLik
      AICtotal<-AICtotal+AIC(fitgr)
          } #clm

    if (comp==1)listfit<-res
    if (comp>1)listfit<-append(listfit,res)

      }  ## comp

  names(listfit) <- newlist

  retlist<-list("loglikfullmodel"=logliktotal, "AIC"=AICtotal, "listfit"=listfit)

  attr(retlist, "structure") <- listcat

  return(retlist)
}
