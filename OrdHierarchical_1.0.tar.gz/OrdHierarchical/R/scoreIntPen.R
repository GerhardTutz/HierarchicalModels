scoreIntPen <-
function (beta,respm,ngr,X,indagr,C, lambda){
    
    ### k-1 matrices
    n<-dim(X)[1]
    k<- dim(respm)[2]
    k1<-k-1
    ones<- matrix(1,k-1,1)
    prob<- matrix(0,n,k-1)
    cumprob<- matrix(0,n,k-1)
    dimdum<- length(beta)
    score <- matrix(0,dimdum,1)
    
    for (i in 1:n){
      #etam <- cbind(diag(k-1),-ones%*%X[i,])  ### design matrix X!
      etam <- cbind((1-indagr[i])*diag(k-1),indagr[i]*diag(k-1),-ones%*%X[i,])   ### predictor - x
      ### probabilities
      prob[i,1]<- exp(etam[1,]%*%beta)/(1+exp(etam[1,]%*%beta))
      cumprob[i,1]<- prob[i,1]
      if(k >=3){for (j in 2:(k-1)) {prob[i,j]<-exp(etam[j,]%*%beta)/(1+exp(etam[j,]%*%beta)) -
        exp(etam[j-1,]%*%beta)/(1+exp(etam[j-1,]%*%beta))
        cumprob[i,j]<-exp(etam[j,]%*%beta)/(1+exp(etam[j,]%*%beta))}}
      
      #prob[i,k]<- 1-sum(prob[i,])
      
      ### covariance
      #vect<-matrix(prob[i,],k-1,1)
      if(k1 >=2)Sigma <- (diag(prob[i,])-prob[i,]%*%t(prob[i,]))/ngr[i]
      if(k1 <2) Sigma <- ((prob[i,])-prob[i,]*(prob[i,]))/ngr[i]
      ### Derivative 
      D<- matrix(0,k-1,k-1)
      for(ii in 1:k1) {
        for(r in 1:k1){if(ii <= r)D[ii,r]<- 1/((1-cumprob[i,r])*cumprob[i,r])
        }}
      D <- solve(D)
      #det(D)
      Sigmainv<-solve(Sigma)
      
      respshort<- respm[i,1:k1]/ngr[i]  ### relative frequencies
      score <- score +t(etam)%*%D%*%Sigmainv%*%(respshort-prob[i,])
    }## end i
    
    ## loglik 
    #score<-score-2*lambda*as.numeric(C%*%as.matrix(beta))*t(C)
    score<-score- lambda* 2* t(C)%*%C%*%beta  #as.numeric(C%*%as.matrix(beta))*t(C)
    score <- -score ### negative log-likelihood
    return(score)
  }
