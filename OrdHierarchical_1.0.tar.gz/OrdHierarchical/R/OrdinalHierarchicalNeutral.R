OrdinalHierarchicalNeutral <-
function(dat,k,nameresp,predn,prednonn,preda,preddis,tests,preddisp,predequal,cum){

  d<-MakeDesign(dat,k,nameresp,predn,preda,preddis)
  d

  ## fit neutral

  ###################################
  ### fits neutral versus non-neutral

  incr<-.2
  knew<-dim(as.matrix(d$respmsepneut))[2]
  thr<- seq(1,knew-1,1)*incr
  beta<-c(thr,rep(.0,length(predn)))
  d$Xsepneut<-as.matrix(d$Xsepneut)

  #Loglikcum(beta,d$respmgr,d$ngrgr,d$Xgr)
  fitsgr <- suppressWarnings(optim(beta, Loglikcum, gr = scorecum,d$respmsepneut,d$ngsepneut,d$Xsepneut,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))

  errgr<- solve(fitsgr$hessian)
  stdgr<- sqrt(diag(errgr))
  probgr<-LoglikcumFit(fitsgr$par,d$respmsepneut,d$Xsepneut,d$Xsepneut)

  ##output generation

  z<-fitsgr$par/stdgr
  pvalgr <-(1-pnorm(abs(z), mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE))*2

  parmgr<- cbind(fitsgr$par,stdgr,z,pvalgr)
  parmgr<-as.data.frame(parmgr)

  names(parmgr)[1] <- "Estimates"
  names(parmgr)[2] <- "std err"
  names(parmgr)[3] <- "z-values"
  names(parmgr)[4] <- "p-values"
  if(length(predn)>0)row.names(parmgr)<-c(seq(1,(knew-1),1),paste(predn))


  ###################### end neutral

  ################fits disagree,agree hierarchical model

  ## non neutral data set: datred
  dat$resp0<-as.matrix(dat[,nameresp])
  dat$resp0<-as.numeric(dat$resp0)

  dat$redu<-dat$resp0
  for(i in 1:dim(dat)[1]){if(dat$resp[i] ==((k+1)/2)) {dat$redu[i] <- NA}}
  for(i in 1:dim(dat)[1]){if(dat$resp[i] >=((k+3)/2)) {dat$redu[i] <- dat$redu[i]-1}}

  datred <- na.omit(dat)

  if(!cum){


  hierred <- OrdinalHierarchical(datred, k-1, nameresp="redu", prednonn, preda, preddis,tests,preddisp,predequal)

  knew<-dim(as.matrix(d$respm))[2]
  incr<-.1
  thr<- seq(1,knew-1,1)*incr
  beta<-c(thr,thr,rep(.0,length(preddis)),rep(.0,length(preda)))

  fits <- suppressWarnings(optim(beta, LoglikInt, gr = scoreInt,d$respm,d$ngr,d$X,d$indagr,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))

  err<- solve(fits$hessian)
  std<- sqrt(diag(err))


  ### log-likelihood

  loglik<--fitsgr$value+hierred$loglikfullmodel
  numpar<-1+length(predn)+1+length(prednonn)+length(preda)+length(preddis)+2*(k-3)/2
  AIC<--2*(loglik-numpar)

  newList <- list("loglikfullmodel"=loglik, "AIC"=AIC, "numpar"=numpar, "parneutral"=parmgr, "loglikneutral"=-fitsgr$value,
                  "fitnonneutral"=hierred)



  }  ## cum nonyes
  ################fits disagree,agree cumulative model

  if(cum){

    Xnonn<-as.matrix(datred[,prednonn])  ### !!!!!!
    respmnonn<- matrix(0,dim(Xnonn)[1],k-1)
    for (i in 1:dim(Xnonn)[1]) respmnonn[i,datred$red[i]]<-1
    ngrnonn <- rep(1,dim(Xnonn)[1])


    incr<-.2
    knew<-dim(as.matrix(respmnonn))[2]
    thr<- seq(1,knew-1,1)*incr
    beta<-c(thr,rep(.0,length(prednonn)))
    Xnonn<-as.matrix(Xnonn)

    #Loglikcum(beta,respmnonn,ngrnonn,Xnonn)
    fitsnonn <- suppressWarnings(optim(beta, Loglikcum, gr = scorecum,respmnonn,ngrnonn,Xnonn,method = "BFGS",lower = -Inf, upper = Inf,control = list(), hessian = TRUE))

    errnonn<- solve(fitsnonn$hessian)
    stdnonn<- sqrt(diag(errnonn))
    #probgr<-LoglikcumFit(fitsgr$par,d$respmgr,d$ngrgr,d$Xgr)


    ##output generation

    z<-fitsnonn$par/stdnonn
    pvalgr <-(1-pnorm(abs(z), mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE))*2

    parmnonn<- cbind(fitsnonn$par,stdgr,z,pvalgr)
    parmnonn<-as.data.frame(parmnonn)

    names(parmnonn)[1] <- "Estimates"
    names(parmnonn)[2] <- "std err"
    names(parmnonn)[3] <- "z-values"
    names(parmnonn)[4] <- "p-values"
    if(length(prednonn)>0)row.names(parmnonn)<-c(seq(1,(knew-1),1),paste(prednonn))

    ### log-likelihood

    logliknonn<--fitsgr$value-fitsnonn$value
    numpar<-1+length(predn)+knew-1+length(prednonn)
    AICnonn<--2*(logliknonn-numpar)

    newList <- list("loglikfullmodel"=logliknonn, "AIC"=AICnonn, "numpar"=numpar, "parneutral"=parmgr, "loglikneutral"=-fitsgr$value,
                    "fitnonneutral"=parmnonn, "logliknonneutral"=-fitsnonn$value)


  } # end cum yes

    ############################

  return(newList)


}
