LoglikcumFit <-
function (beta,respm,ngr,X){
    
    #### returns fitted probabilities
    #### model Y <= r in predictor - x
    #### respm: responses as counts in n x k matrix 
    #### ngr:   numbers of observations at fixed value (n x 1) not needed in loglik (but score)
    
    #returns fitted probabilities
    n<-dim(X)[1]
    k<- dim(respm)[2]
    ones<- matrix(1,k-1,1)
    prob<- matrix(0,n,k)
    probobs<- matrix(0,n,1) #probabilities observed responses
    
    ind<- matrix(0,n,k)
    for (i in 1:n){
      etam <- cbind(diag(k-1),-ones%*%X[i,])   ### predictor - x
      prob[i,1]<- exp(etam[1,]%*%beta)/(1+exp(etam[1,]%*%beta))
      if(k >=3){for (j in 2:(k-1)) {prob[i,j]<-exp(etam[j,]%*%beta)/(1+exp(etam[j,]%*%beta)) -
        exp(etam[j-1,]%*%beta)/(1+exp(etam[j-1,]%*%beta))}
        #ind[i,j]<-NegVal(prob[i,j])
      }
      prob[i,k]<- 1-sum(prob[i,])
      for (ii in 1:k)if (respm[i,ii]==1)probobs[i,1]<-prob[i,ii]
      #ind[i,k]<-NegVal(prob[i,k])
    }
    
    ## loglik 
    #loglik <-0
    #for (i in 1:n)loglik <- loglik +respm[i,]%*%log(prob[i,])
    
    #loglik <- -loglik ### negative log-likelihood
    
    return(probobs) ## returns prob observed
  }
