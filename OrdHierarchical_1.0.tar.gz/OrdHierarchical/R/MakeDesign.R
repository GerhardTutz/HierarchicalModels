MakeDesign <-
function (dat,k,nameresp,pred,preda,preddis){  
  
  ## generates design and response fit disagree, agree categories, model <r and -x 
  
  ## dat: data frame
  ## k: number of categories
  ## namesresp: response variable
  ##  pred: names predictors grouped response
  ##  preda: names predictors agreement categories
  ##  preddis: names predictors disagreement categories
  
  # output  
  ## $datmod is modified data, contains variables resp0 (response), respgr (grouped response, 3 categories if k odd, 2 if k even)
  
  ## respmgr: respmatrix for grouped response
  ## ngrgr: uninteresting, just ones
  ## Xgr:  explanatory variables for groped response
  
  
  ## respm: respmatrix for  response in non-neutral categories (3 categories if k=6 or 7)
  ## ngr: uninteresting
  ## X: explanatory variables for response in non-neutral categories
  ##    order: disagree, agree
  
  dat$resp0<-as.matrix(dat[,nameresp])  
  dat$resp0<-as.numeric(dat$resp0)  
  dat$respgr<-0
  dat$respneut<-1  ## if non-neutral: 1, if neutral: 2  
  
  ### k odd 
  if(k/2 !=floor(k/2)) { 
    lim<-dim(dat)[1]
    
    ## grouped
    for (i in 1:lim) {if (dat$resp0[i]<=(k-1)/2)dat$respgr[i]<-1
    if (dat$resp0[i]>=(k+1)/2+1) dat$respgr[i]<-3
    if (dat$resp0[i]==(k+1)/2) dat$respgr[i]<-2
    dat$obs[i]=i
    if (dat$resp0[i]==(k+1)/2)dat$respneut[i]<-2}
    
    Xgr<-as.matrix(dat[,pred])  ### !!!!!!
    respmgr<- matrix(0,dim(Xgr)[1],3)
    for (i in 1:dim(Xgr)[1]) respmgr[i,dat$respgr[i]]<-1
    ngrgr <- rep(1,dim(Xgr)[1])
    
    Xsepneut<-as.matrix(dat[,pred])  ### !!!!!!
    respmsepneut<- matrix(0,dim(Xsepneut)[1],2)
    for (i in 1:dim(Xsepneut)[1]) respmsepneut[i,dat$respneut[i]]<-1
    ngsepneut <- rep(1,dim(Xsepneut)[1])
    
    ##subsamples
    
    datdis<-dat[dat$resp0<=(k-1)/2,]  ## disagree
    #datdis$respresc<-(k+1)/2-datdis$resp  ## rescaled response inverted!
    datdis$respresc<-datdis$resp0 ###original
    datdis$indagr<-0   ### indicator agreement categories
    
    
    datagr<-dat[dat$resp0>=(k+1)/2+1,]  ## agree
    datagr$respresc<-  datagr$resp0-(k+1)/2  ## 
    datagr$indagr<-1
    
    datagdis<- rbind(datdis,datagr)  ### all observation without neutral
    indagr<-c(datdis$indagr,datagr$indagr)
    
    respdis<-datdis$respresc
    respagr<-datagr$respresc
    resp<-as.matrix(c(datdis$respresc,datagr$respresc))
    obsind<-c(datdis$obs,datagr$obs)
    
    Xdis<-cbind((datdis[,preddis]),0*(datdis[,preda]))
    Xa<-cbind((0*datagr[,preddis]),(datagr[,preda]))
    dim(Xdis)
    dim(Xa)
    Xdis<-as.matrix(Xdis)
    Xa<-as.matrix(Xa)
    X <-rbind(Xdis,Xa)
    #X<- as.matrix(X)  
    
    ### response matrix
    knew<-(k-1)/2
    k1<- knew-1
    n <-  dim(X)[1]
    p <-  dim(X)[2]
    
    respm<- matrix(0,n,knew)
    for (i in 1:n) respm[i,resp[i]]<-1
    ngr <- rep(1,n)
    } # end k
    
  
  #### k even
  if(k/2 ==floor(k/2)) { 
    lim<-dim(dat)[1]
    
    ## grouped
    for (i in 1:lim) {if (dat$resp0[i]<=(k)/2)dat$respgr[i]<-1
    if (dat$resp0[i]>=(k)/2+1) dat$respgr[i]<-2
    dat$obs[i]=i}
    
    Xgr<-as.matrix(dat[,pred])  ### !!!!!!
    respmgr<- matrix(0,dim(Xgr)[1],2)
    for (i in 1:dim(Xgr)[1]) respmgr[i,dat$respgr[i]]<-1
    ngrgr <- rep(1,dim(Xgr)[1])
    
    
    
    ##subsamples
    
    datdis<-dat[dat$resp0<=(k)/2,]  ## disagree
    #datdis$respresc<-(k+1)/2-datdis$resp  ## rescaled response inverted!
    datdis$respresc<-datdis$resp0 ###original
    datdis$indagr<-0   ### indicator agreement categories
    
    
    datagr<-dat[dat$resp0>=(k)/2+1,]  ## agree
    datagr$respresc<-  datagr$resp0-(k)/2  ## 
    datagr$indagr<-1
    
    datagdis<- rbind(datdis,datagr)  ### all observation without neutral
    indagr<-c(datdis$indagr,datagr$indagr)
    
    respdis<-datdis$respresc
    respagr<-datagr$respresc
    resp<-as.matrix(c(datdis$respresc,datagr$respresc))
    obsind<-c(datdis$obs,datagr$obs)
    
    Xdis<-cbind((datdis[,preddis]),0*(datdis[,preda]))
    Xa<-cbind((0*datagr[,preddis]),(datagr[,preda]))
    
    Xdis<-as.matrix(Xdis)
    Xa<-as.matrix(Xa)
    X <-rbind(Xdis,Xa)
    #X<- as.matrix(X)  
    
    ### response matrix
    knew<-k/2
    k1<- knew-1
    n <-  dim(X)[1]
    p <-  dim(X)[2]
    
    respm<- matrix(0,n,knew)
    for (i in 1:n) respm[i,resp[i]]<-1
    ngr <- rep(1,n)
  
    ### only for output needed
    Xsepneut<-as.matrix(dat[,pred])  ### !!!!!!
    respmsepneut<- matrix(0,dim(Xsepneut)[1],2)
    #for (i in 1:dim(Xsepneut)[1]) respmsepneut[i,dat$respneut[i]]<-1
    ngsepneut <- rep(1,dim(Xsepneut)[1])
    
      } # end k
  
  
    newList <- list("respmgr"=respmgr, "ngrgr"= ngrgr,"Xgr"= Xgr,"respm"=respm, "ngr"= ngr,"X"= X,"indagr"=indagr, "datmod"=dat, "datdis"=datdis,"datagr"=datagr,
                    "obsind"=obsind, "respmsepneut"=respmsepneut,"ngsepneut"= ngsepneut,"Xsepneut"=Xsepneut)
    
    
    return(newList)}
