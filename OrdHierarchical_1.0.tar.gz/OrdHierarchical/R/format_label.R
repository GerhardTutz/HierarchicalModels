format_label <-
function(vec) paste(sort(vec), collapse = ",")
