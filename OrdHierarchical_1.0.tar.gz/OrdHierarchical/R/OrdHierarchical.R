#' Structured Hierarchical Regression for Likert Scales Including Dispersion Effects
#'
#'@description
#'A function to fit hierarchical models for Likert scales with k categories. The standard application is for response categories that
#'can be described by strong disagreement, ...,neutral, ..., strong agreement. The function also provides tests if the effects are the same or can be considered
#'as dispersion effects. More general hierarchies can be fitted by specifying the hierarchy by a list of splits of categories accompanied
#'by a list of explanatory variables that refer to the splits. Cumulative as well as adjacent categories link functions can be used.
#'A detailed description of the models is given in Tutz and Berger (2026).
#'
#'
#'@param dat Data.frame of class \code{\link{data.frame}} containing the variables of the model.
#'@param k Number of response categories.
#'@param nameresp Name of the response variable. Needs to be part of \code{dat}.
#'@param fittype Fitting algorithm used for optimization. If \code{fittype="disp"} the model may include dispersion effects for the variables in argument \code{preddisp}, and optimization
#'is performed by \code{\link[stats]{optim}}. If \code{fittype="clm"} or \code{fittype="vglm"} the model can not include dispersion effects and optimization is performed
#'by \code{\link[ordinal]{clm}} or \code{\link[VGAM]{vglm}}.
#'@param modeltype Type of model to be fitted. If \code{modeltype="split"} an ordinal structure distinguishing between disagreement, neutral and agreement is fitted.
#'If \code{modeltype="neutral"}, the neutral category is separated and a model distinguishing between disagreement and agreement is fitted. If \code{modeltype="general"} a hierarchical model is fitted
#'determined by the list of category sets in \code{general_structure} and the covariates in \code{pred}. \code{modeltype="general"} can only be used if \code{fittype="clm"} or \code{fittype="vglm"}.
#'@param cum Indicator, if in the second step a cumulative model including the agreement and disagreement categories is fitted. If \code{cum=FALSE} two separate models within the agreement and disagreement
#'categories are fitted in the second step. Only, if \code{modeltype="neutral"}.
#'@param pred Character vector of covariates used in the first step (ordinal model distinguishing between disagreement and agreement categories).
#'@param preda Optional vector of covariates used for fitting the model within agreement categories.
#'@param preddis Optional vector of covariates used for fitting the model within disagreement categories.
#'@param predneutral Character vector of covariates used for fitting the model that distinguishes between neutral category and the set of other categories. Only, if \code{modeltype="neutral"}.
#'@param preddisp Character vector of covariates with dispersion effects (same size but opposite sign). Only, if \code{fittype="disp"} and \code{cum=FALSE}.
#'@param predequal Optional character vector of covariates with equal effects. Only, if \code{fittype="disp"} and \code{cum=FALSE}. Not possible in combination with dispersion effects.
#'@param general_structure List of category sets defining the hierarchical model to be fitted. Only, if \code{modeltype="general"}.
#'@param general_pred List of vectors of covariates used for fitting in each node. Only, if \code{modeltype="general"}.
#'@param tests Type of test (likelihood ratio or Wald) to test (i) for the equality of effects in agreement and disagreement categories, and (ii) for the presence of dispersion effects (same size but opposite sign),
#'are performed. Only, if \code{fittype="disp"} and \code{predequal=NULL}, \code{preddisp=NULL}.
#'@param family type of link function that is used to link the mean responses to the linear predictors of the model; one out of \code{"cumulative"} and \code{"acat"}.
#'Only, if \code{fittype="clm"} or \code{fittype="vglm"}.
#'@param x Object of class \code{OrdHierarchical}.
#'@param ... Further arguments passed to or from other methods.
#'
#'@details
#'Likert scales that can be described by strong disagreement,...,neutral,..., strong agreement are fitted when setting \code{modeltype="split"}. For such responses
#'the hierarchy is built by splitting into categories (1,...,k/2) and (k/2+1,...,k) if k is even, and into groups (1,..,(k-1)/2), (k+1)/2, ((k+3)/2,...,k) if k is odd.
#'In the next step two separate ordinal models are fitted within agreement and agreement categories, unless \code{cum=TRUE}. Different sets of explanatory variables can be used within the sets of categories,
#'specified by \code{preda} and \code{preddis}. If the number of response categories is odd, a model can be fitted that in the first split separates the middle category (k+1)/2 from the other
#'categories \code{modeltype="neutral"}. A binary model is then used to model the response neutral category or not. Within the subsets agreement and disagreement categories ordinal models are fitted.
#'
#'Tests are provided that evaluate if the effects of covariates are the same in the model for disagreement categories and for agreement categories, if \code{tests=TRUE}. In addition it is tested if
#'the effects can be considered dispersion effects, that is, if the have the opposite sign in disagreement and agreement categories. Tests work only if the same set of covariates is
#'used in the models for disagreement and agreement categories.
#'
#'Hierarchical models are not restricted to Likert scales. More general hierarchies can be fitted if \code{modeltype="general"} by specifying the hierarchy by a list of splits \code{general_structure} of categories accompanied
#'by a list of explanatory variables \code{general_pred} that refer to the splits. See examples.
#'
#'Note: The convention in the ordinal models that are fitted is such that large values of the linear predictor indicate the preference of high categories (or the neutral category,
#'if it is separated). In current alternative implementations of cumulative models (\code{\link[ordinal]{clm}} or \code{\link[VGAM]{vglm}}) the effects are often reversed.
#'
#'
#'@return
#'The function returns a list of class \code{OrdHierarchical} with the following slots.
#'
#'If \code{fittype="disp"} and \code{modeltype="split"}
#'
#'\item{loglikfullmodel}{loglikelihood of the hierarchical model}
#'\item{AIC}{AIC of the hierarchical model}
#'\item{pargroupedresponse}{parameter estimates for cumulative model with grouping disagreement, neutral (if present), agreement}
#'\item{loglikgroupedmodel}{log-likelihood of the model for grouped response}
#'\item{parnonneutral}{parameters for the cumulative models for disagreement and agreement categories}
#'\item{logliknonneutral}{log-likelihood of the model for disagreement and agreement categories}
#'\item{pardispersionmodel}{parameters for the cumulative models for disagreement and agreement categories with dispersion effects (if \code{preddisp} is not NULL)}
#'\item{loglikdispersionmodel}{log-likelihood of the model with dispersion effects (if \code{preddisp} is not NULL)}
#'\item{AICdisp}{AIC of the model with dispersion effects}
#'\item{testsequality}{tests if effects are the same within disagreement and agreement categories}
#'\item{testsdispersion}{tests if effects can be considered dispersion effects (opposite signs)}
#'
#'If \code{fittype="disp"} and \code{modeltype="neutral"}
#'
#'\item{loglikfullmodel}{loglikelihood of the hierarchical model}
#'\item{AIC}{AIC of the hierarchical model}
#'\item{numpar}{number of parameters}
#'\item{parneutral}{parameters for the binary model that distinguishes between the neutral category and the other categories}
#'\item{loglikneutral}{log-likelihood of the binary model}
#'\item{fitnonneutral}{list as for modeltype="split" (if \code{cum=FALSE})}
#'\item{parnonneutral}{parameters for the cumulative model (if \code{cum=TRUE})}
#'\item{logliknonneutral}{log-likelihood of the cumulative model (if \code{cum=FALSE})}
#'
#'If \code{fittype="clm"} or \code{fittype="vglm"}
#'
#'\item{loglikfullmodel}{loglikelihood of the hierarchical model}
#'\item{AIC}{AIC of the hierarchical model}
#'\item{listfit}{list of models, where each element corresponds to the output by \code{\link[ordinal]{clm}} or \code{\link[VGAM]{vglm}}, respectively}
#'
#'@author
#' Moritz Berger <Moritz.Berger@zi-mannheim.de> \cr Gerhard Tutz <Gerhard.Tutz@stat.uni-muenchen.de>
#'
#'@references
#'Tutz, G, Berger, M (2026). Structured hierarchical regression for Likert scales including dispersion effects: Models and fitting tools, Psychological Methods.
#'
#'@seealso \code{\link[ordinal]{clm}}, \code{\link[VGAM]{vglm}}
#'
#'@examples
#'data(GLES)
#'
#'hier <- OrdHierarchical(dat=GLES, k=7, nameresp="Terrorism",
#'fittype="disp", cum=TRUE, pred=c("Age","Gender","Abitur"))
#'hier
#'
#'hier2 <- OrdHierarchical(dat=GLES, k=7, nameresp="Terrorism",
#'fittype="clm", pred=c("Age","Gender","Abitur"))
#'hier2
#'
#'@importFrom ordinal clm
#'@importFrom VGAM vglm cumulative acat
#'@importFrom stats AIC as.formula logLik na.omit optim pchisq pnorm
#'@export
#'

OrdHierarchical <- function(dat,
                            k,
                            nameresp,
                            fittype=c("disp","clm","vglm"),
                            modeltype=c("split","neutral","general"),
                            cum=FALSE,
                            pred,
                            preda=NULL,
                            preddis=NULL,
                            predneutral=NULL,
                            preddisp=NULL,
                            predequal=NULL,
                            general_structure=NULL,
                            general_pred=NULL,
                            tests=c("Wald","LR"),
                            family=c("cum","acat"),
                            ...){

  # check input
  if(missing(dat)){
    stop("Argument dat is missing with no default.")
  }
  if(missing(k)){
    stop("Argument k is missing with no default.")
  }
  if(missing(nameresp)){
    stop("Argument nameresp is missing with no default.")
  }
  if(missing(pred)){
    stop("Argument pred is missing with no default.")
  }
  fittype <- match.arg(fittype)
  modeltype <- match.arg(modeltype)
  tests <- match.arg(tests)
  family <- match.arg(family)

  if(fittype=="disp"){
    if(modeltype=="split"){
      if(is.null(preda)) preda <- pred
      if(is.null(preddis)) preddis <- pred
      if(!all(preda==preddis)) tests <- "no"
      mhier <- OrdinalHierarchical(dat, k, nameresp, pred, preda, preddis, tests, preddisp, predequal)
    }
    if(modeltype=="neutral"){
      prednonn    <- pred
      if(is.null(predneutral)) predneutral <- pred
      if(is.null(preda)) preda <- pred
      if(is.null(preddis)) preddis <- pred
      if(cum) preddisp <- NULL
      if(cum) predequal <- NULL
      if(!all(preda==preddis)) tests <- "no"
      mhier <- OrdinalHierarchicalNeutral(dat, k, nameresp, predneutral, prednonn, preda, preddis, tests, preddisp, predequal, cum)
    }
  }
  if(fittype!="disp"){
    if(modeltype=="split"){
      if(is.null(preda)) preda <- pred
      if(is.null(preddis)) preddis <- pred
      mhier<- OrdinalHierarchicalTrees(dat, k, nameresp, pred, preda, preddis, fittype, family)
    }
    if (modeltype=="neutral"){
      if(is.null(predneutral)) predneutral <- pred
      predn <- predneutral
      mhier<- OrdinalHierarchicalTreesNeutral(dat, k, nameresp, pred, predn, fittype, cum, family)
    }
    if(modeltype=="general"){
      if(is.null(general_pred)) general_pred <- replicate(length(general_structure), pred, simplify = FALSE)
      mhier <- PolyTreesGen(dat, k, nameresp, general_structure, general_pred, fittype, family)
    }
  }
  class(mhier) <- "OrdHierarchical"
  attr(mhier, "call") <- match.call()
  return(mhier)
}

#' @rdname OrdHierarchical
#' @method print OrdHierarchical
#' @export

print.OrdHierarchical <-
  function(x, # object of class OrdHierarchical
           ...){

  attr(x, "structure") <- NULL
  x <- unclass(x)
  print(x)

  }

#' @rdname OrdHierarchical
#' @export

test_dispersion <-
  function(x, # object of class OrdHierarchical
           tests,
           ...){

  if(as.list(attributes(x)$call)[-1]$fittype!="disp"){
    stop("Function test_dispersion is only applicable for fittype 'disp'")
  }

  if(tests == "LR") print ("Likelihood ratio tests if variables have dispersion effect")
  if(tests == "Wald") print ("Wald tests if variables have dispersion effect")

  if(as.list(attributes(x)$call)[-1]$modeltype=="split"){
   print(round(x$testsdispersion ,digits=3))
  }
  if(as.list(attributes(x)$call)[-1]$modeltype=="neutral"){
   print(round(x$fitnonneutral$testsdispersion ,digits=3))
  }
}

#' @rdname OrdHierarchical
#' @export

test_equality <-
  function(x, # object of class OrdHierarchical
           tests,
           ...){

  if(as.list(attributes(x)$call)[-1]$fittype!="disp"){
    stop("Function test_equality is only applicable for fittype 'disp'")
  }

  if(tests == "LR") print ("Likelihood ratio tests for equality of effects within disagreement and agreement effects")
  if(tests == "Wald") print ("Wald tests for equality of effects within disagreement and agreement effects")

  if(as.list(attributes(x)$call)[-1]$modeltype=="split"){
    print(round(x$testsequality ,digits=3))
  }
  if(as.list(attributes(x)$call)[-1]$modeltype=="neutral"){
    print(round(x$fitnonneutral$testsequality ,digits=3))
  }
}







